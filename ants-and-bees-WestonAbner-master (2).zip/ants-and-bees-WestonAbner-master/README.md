# Ants vs. Some-Bees

This module is a simple turn-based tower-defense game played on the command-line, created for the Software Architecture course at the UW iSchool.  The below questions should be answered regarding your submission!  

##### Did you receive help from any other sources (classmates, etc)? If so, please list who (be specific!). #####
> yes but it didnt help, eric bunch, eric brewer, brandon sitz

##### Approximately how many hours did it take you to complete this assignment? #####
>9
##### On a scale of 1 (too easy) to 10 (too challenging), how difficult was this assignment? #####
> 7

##### Did you encounter any problems in this assignment we should warn students about in the future? How can we make the assignment better? #####
> give clearer instructions for how to get typedc working. I had alot of typedoc errors and spent more time messing with typedoc then i did with the actual assighnment
